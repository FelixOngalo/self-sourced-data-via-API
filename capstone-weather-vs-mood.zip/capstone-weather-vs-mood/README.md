# Capstone: [Your Original Question Here]

This is the capstone project: unlike the earlier ones, there's no ready-made
dataset. You pick a question you actually care about, pull the data yourself
through an API or web scraping, and answer it. This is usually the project
interviewers ask about most, because it shows you can do the whole job, not
just the analysis step.

**This repo ships as a working EXAMPLE** (free weather API, no key needed) so
you have a real, runnable pipeline to learn the pattern from. Swap the
question and data source for your own once you see how it fits together —
see "Make it yours" below.

## Example question

Is there a relationship between weather (temperature, rainfall) and how
"busy" a city's air feels, using a free public weather/air-quality API as a
stand-in for any time-series question you could ask about your own interests
(sports stats, transit delays, game prices, local events...).

**Key findings:** *(fill in after running)*

**Tools:** R, httr2, jsonlite, tidyverse, Quarto

## Reproduce

1. `install.packages(c("httr2", "jsonlite", "tidyverse", "janitor", "quarto"))`
2. Run `R/00_fetch_data.R` — pulls data from the Open-Meteo API (free, no signup, no key)
3. Run `R/01_clean.R`
4. Render `reports/report.qmd`

## How this pattern generalizes

| Step | What it does here | How you'd adapt it |
|---|---|---|
| `R/00_fetch_data.R` | Calls a weather API with `httr2`, handles pagination/rate limits | Point it at any REST API: Reddit, GitHub, a sports-stats API, your city's open-data portal |
| `R/api_helpers.R` | Wraps the API call, retries on failure, logs progress | Keep the pattern, change the URL and the parsing of the response |
| `R/cleaning.R` | Parses nested JSON into a tidy data frame | Adjust to your API's actual response shape |
| `reports/report.qmd` | One question, EDA, interpretation, recommendation | Replace with your own question |

If scraping instead of an API: swap `httr2::request()` calls for `rvest::read_html() |> html_elements()`, and **always check the site's robots.txt and terms of service first** — some sites prohibit scraping even when technically possible.

## Make it yours

Good capstone question sources:
- A hobby or interest: sports stats (many leagues have free APIs), video game prices (Steam API), music listening history (Spotify API)
- Local life: your city/state open-data portal (transit delays, crime stats, permits), similar to the NYC 311 project but self-sourced
- Current events: a public API tracking something you follow (weather extremes, air quality, elections data)

A good capstone question is specific, answerable with data you can actually get, and something you'd explain enthusiastically in an interview.

## Project structure

```
R/00_fetch_data.R     pulls raw data from an API
R/api_helpers.R        reusable request/retry/logging functions
R/cleaning.R            parses and tidies the raw response
R/01_clean.R            runs the cleaning
reports/report.qmd      question, EDA, findings, recommendation
```

## Limitations

*(fill in — note anything about data freshness, API limits, or scope)*
