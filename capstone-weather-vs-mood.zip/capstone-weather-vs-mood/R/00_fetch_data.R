# Fetch daily weather data from Open-Meteo (free, no API key required).
# https://open-meteo.com/en/docs -- good first API to practice on since
# it needs no authentication, which lets you focus on the request/response
# pattern itself before dealing with API keys.
#
# TO MAKE THIS YOUR OWN CAPSTONE: replace this file's URL and parameters
# with whatever API answers YOUR question. The pattern (build URL -> call
# api_get_json() -> bind_rows() -> save) stays the same.

library(dplyr)
library(purrr)
library(jsonlite)
source("R/api_helpers.R")

# A handful of cities to compare -- swap for locations relevant to your question
cities <- tribble(
  ~city,        ~lat,    ~lon,
  "New York",   40.7128, -74.0060,
  "Chicago",    41.8781, -87.6298,
  "Miami",      25.7617, -80.1918,
  "Seattle",    47.6062, -122.3321,
  "Denver",     39.7392, -104.9903
)

start_date <- "2025-01-01"
end_date   <- "2025-12-31"

fetch_city_weather <- function(city, lat, lon) {
  url <- paste0(
    "https://archive-api.open-meteo.com/v1/archive",
    "?latitude=", lat, "&longitude=", lon,
    "&start_date=", start_date, "&end_date=", end_date,
    "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum",
    "&timezone=auto"
  )

  message("Fetching: ", city)
  result <- api_get_json(url)
  polite_pause(1)   # be a considerate API citizen

  as_tibble(result$daily) |>
    mutate(city = city, .before = 1)
}

raw <- pmap_dfr(cities, fetch_city_weather)

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
saveRDS(raw, "data/raw/weather_raw.rds")
message("Saved ", nrow(raw), " rows across ", nrow(cities), " cities.")
