library(dplyr)
source("R/cleaning.R")

raw   <- readRDS("data/raw/weather_raw.rds")
clean <- clean_weather(raw)

cat("Rows before:", nrow(raw), "\n")
cat("Rows after: ", nrow(clean), "\n")
cat("Cities:", paste(unique(clean$city), collapse = ", "), "\n")
cat("Date range:", as.character(min(clean$date)), "to", as.character(max(clean$date)), "\n")

saveRDS(clean, "data/clean/weather_clean.rds")
