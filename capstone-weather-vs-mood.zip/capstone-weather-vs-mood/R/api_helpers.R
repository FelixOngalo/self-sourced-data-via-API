# Reusable helpers for talking to a REST API politely and reliably.
# These patterns (retry, rate-limit pause, error check) apply to almost
# any public API you point this project at later.

library(httr2)

# Build a request with sane defaults: a descriptive user agent (many APIs
# require or appreciate this), and automatic retry on transient failures.
api_request <- function(url) {
  request(url) |>
    req_user_agent("r-portfolio-capstone (learning project)") |>
    req_retry(max_tries = 3, backoff = ~ 2) |>
    req_error(is_error = \(resp) FALSE)   # handle errors ourselves below
}

# Perform the request and return parsed JSON, or stop with a clear message.
api_get_json <- function(url) {
  resp <- api_request(url) |> req_perform()

  if (resp_status(resp) >= 400) {
    stop("API request failed [", resp_status(resp), "]: ", url)
  }

  resp_body_json(resp, simplifyVector = TRUE)
}

# Small pause between calls -- considerate API usage, avoids rate limits.
polite_pause <- function(seconds = 1) Sys.sleep(seconds)
