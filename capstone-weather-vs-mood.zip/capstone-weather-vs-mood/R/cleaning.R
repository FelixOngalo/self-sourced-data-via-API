library(dplyr)
library(lubridate)
library(janitor)

clean_weather <- function(raw) {
  raw |>
    clean_names() |>
    rename(
      date     = time,
      temp_max = temperature_2m_max,
      temp_min = temperature_2m_min,
      precip   = precipitation_sum
    ) |>
    mutate(
      date        = as_date(date),
      temp_avg    = (temp_max + temp_min) / 2,
      month       = month(date, label = TRUE),
      is_rainy    = precip > 1   # >1mm counted as a rainy day
    ) |>
    filter(!is.na(temp_avg))
}
